# Welcome to MAXTRIVIA

### Why are we building a trivia?

More often than not, we see recurring questions popping-up across channels.

With those scenarios in mind, it dawn on us it'd be a fun and entertaining way of learning, as well as re-learning about our products.

Furthermore, it could eventually also be used at summits, as well as at workshops.
