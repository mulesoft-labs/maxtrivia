package com.qa.hackaton;

/**
 * Created by estefaniabertolini on 10/24/16.
 */
public class Anwser {

    public Anwser(String description, boolean isCorrect) {
        this.description = description;
        this.isCorrect = isCorrect;
    }

    String description;
    boolean isCorrect;


}
