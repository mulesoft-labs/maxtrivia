package com.qa.hackaton;

public class QuestionAndAnswers {

    private String Question;
    private String Answer1;
    private String Answer2;
    private String Answer3;

    QuestionAndAnswers(String question, String answ1, String answ2, String answ3) {
        Question = question;
        Answer1 = answ1;
        Answer1 = answ2;
        Answer1 = answ3;

    }

    QuestionAndAnswers(String question, String answ1, String answ2) {
        Question = question;
        Answer1 = answ1;
        Answer1 = answ2;
    }


}
